// client.js

import { io } from 'socket.io-client';
import mysql from 'mysql2/promise'; // เพิ่ม mysql2/promise สำหรับการเชื่อมต่อ MySQL
import dotenv from 'dotenv';
import axios from 'axios';
dotenv.config();

// กำหนด client ID ของตัวเอง
const hosCode = process.env.HOSCODE; 
const hosName = process.env.HOSNAME;

// การตั้งค่าการเชื่อมต่อ MySQL
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
};

// สร้าง connection pool
const pool = mysql.createPool(dbConfig);

// เชื่อมต่อกับ server ผ่าน URL ของ server
const socket = io(process.env.URL_SERVER);


// ส่ง ID ของ client ให้ server เมื่อเชื่อมต่อ
socket.on('connect', () => {
    console.log(`--> agent: เชื่อมต่อไปยัง server ด้วย hosCode: ${hosCode}`);
    socket.emit('register', { hosCode, hosName });  // ส่ง ID ให้ server
});


// รับข้อความทักทายจาก server
socket.on('greeting', (message) => {
    console.log(message);  // แสดงข้อความทักทายจาก server
});

// รับข้อความที่ server ส่งมาเมื่อบันทึกข้อมูลลงฐานข้อมูลสำเร็จ
socket.on('dataResponse', (data) => {
    console.log(data);
}
);

// รอรับคำสั่งจาก server
socket.on('serverCommand', (data) => {
    const { queryName, hosCode, params } = data;
    console.log(`ได้รับคำสั่งจาก server ให้ทำงาน query ชื่อว่า: "${queryName}"`);

    // แสดงผลข้อมูล params ที่ได้รับ
    console.log('ข้อมูลที่ได้รับจาก server (params):', params);


    // ในกรณีนี้ params จะเป็น array ที่เก็บ key-value ของ query parameters
    params.forEach(param => {
        console.log(`พารามิเตอร์: ${param.key} = ${param.value}`);
    });


    fetchData(queryName, hosCode, params).then(db_data => {
        let json_data = JSON.stringify(db_data.data);
        console.log(`hosCode: ${hosCode}, queryName: ${queryName}, data: ${json_data}`);
        // ส่งข้อมูลกลับไปยัง server รูปแบบ JSON
        socket.emit('clientData', { hosCode, queryName, data: json_data });
    });
});


// ฟังก์ชันที่ใช้ดึงข้อมูล
async function fetchData(queryName, hosCode, params) {
    let connection;
    try {
        console.log(`กำลังดึงข้อมูล query: ${queryName}`);
        connection = await pool.getConnection();
        let hisType = process.env.HIS_TYPE;
        // use axios to fetch data from API
        const response = await axios.post(`http://localhost:8080/script/${hisType}/${queryName}`);
        const data = response.data;

        console.log("query จาก API = " + data);

        let sqlQuery = data;

        // แปลง params ให้เป็น object
        let paramObj = params.reduce((acc, { key, value }) => {
            acc[key] = value;  // เพิ่มค่า key-value ใน object
            return acc;
        }, {});

        // paramObj จะถูกแทนที่ใน sqlQuery ด้วยค่าที่กำหนดไว้ใน API query
        sqlQuery = sqlQuery.replace(/\${(.*?)}/g, (match, key) => {
            return paramObj[key] || match;  // ถ้าไม่มี key ใน paramObj จะคืนค่าเดิม (match) 
        });

        console.log("sqlQuery ที่ปรับปรุงแล้ว = " + sqlQuery);

        // ตรวจสอบว่า sqlQuery ถูกต้องก่อนทำการ execute
        if (!sqlQuery) {
            throw new Error('SQL query ไม่ถูกต้อง');
        }

        const [rows] = await connection.execute(sqlQuery);
        console.log(`ดึงข้อมูลเสร็จสิ้น`);

        return {
            queryName,
            data: rows
        };

    } catch (error) {
        console.error(`Database error: ${error.message}`);
        throw error;
    } finally {
        if (connection) connection.release();
    }
}

// จัดการการปิดโปรแกรมอย่างถูกต้อง
process.on('SIGINT', async () => {
    await pool.end();
    console.log('ปิดการเชื่อมต่อ MySQL pool');
    process.exit(0);
});